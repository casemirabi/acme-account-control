<?php
if (!defined('ABSPATH')) exit;

if (!function_exists('acme_api_consumers_table')) {
  function acme_api_consumers_table(): string
  {
    global $wpdb;
    return $wpdb->prefix . 'acme_api_consumers';
  }
}

if (!function_exists('acme_api_consumers_activate')) {
  function acme_api_consumers_activate(): void
  {
    global $wpdb;

    $tableName = acme_api_consumers_table();
    $charsetCollate = $wpdb->get_charset_collate();

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $sql = "CREATE TABLE {$tableName} (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      wp_user_id BIGINT UNSIGNED NOT NULL,
      consumer_name VARCHAR(190) NOT NULL,
      api_key_hash CHAR(64) NOT NULL,
      api_key_prefix VARCHAR(32) NOT NULL DEFAULT '',
      status VARCHAR(20) NOT NULL DEFAULT 'active',
      allowed_services VARCHAR(255) NOT NULL DEFAULT 'clt',
      last_used_at DATETIME NULL DEFAULT NULL,
      last_ip VARCHAR(100) NULL DEFAULT NULL,
      last_user_agent TEXT NULL DEFAULT NULL,
      created_at DATETIME NOT NULL,
      updated_at DATETIME NOT NULL,
      PRIMARY KEY  (id),
      UNIQUE KEY api_key_hash (api_key_hash),
      KEY wp_user_id (wp_user_id),
      KEY status (status)
    ) {$charsetCollate};";

    dbDelta($sql);
  }
}

if (!function_exists('acme_api_consumer_normalize_allowed_services')) {
  function acme_api_consumer_normalize_allowed_services($allowedServices): string
  {
    $serviceSlugs = is_array($allowedServices) ? $allowedServices : explode(',', (string) $allowedServices);
    $serviceSlugs = array_map('sanitize_key', $serviceSlugs);
    $serviceSlugs = array_filter($serviceSlugs, static function ($serviceSlug) {
      return $serviceSlug !== '';
    });
    $serviceSlugs = array_values(array_unique($serviceSlugs));

    if (empty($serviceSlugs)) {
      $serviceSlugs = ['clt'];
    }

    sort($serviceSlugs);
    return implode(',', $serviceSlugs);
  }
}

if (!function_exists('acme_api_consumer_generate_plain_key')) {
  function acme_api_consumer_generate_plain_key(): string
  {
    return 'acme_live_' . wp_generate_password(32, false, false);
  }
}

if (!function_exists('acme_api_consumer_hash_key')) {
  function acme_api_consumer_hash_key(string $plainApiKey): string
  {
    return hash('sha256', $plainApiKey);
  }
}

if (!function_exists('acme_api_consumer_create')) {
  function acme_api_consumer_create(int $wpUserId, string $consumerName, $allowedServices = ['clt'])
  {
    global $wpdb;

    acme_api_consumers_activate();

    if ($wpUserId <= 0 || !get_user_by('id', $wpUserId)) {
      return new WP_Error('acme_invalid_user', 'Usuário inválido.');
    }

    $consumerName = sanitize_text_field($consumerName);
    if ($consumerName === '') {
      $consumerName = 'Consumidor API #' . $wpUserId;
    }

    $allowedServicesText = acme_api_consumer_normalize_allowed_services($allowedServices);
    $plainApiKey = acme_api_consumer_generate_plain_key();

    $inserted = $wpdb->insert(
      acme_api_consumers_table(),
      [
        'wp_user_id' => $wpUserId,
        'consumer_name' => $consumerName,
        'api_key_hash' => acme_api_consumer_hash_key($plainApiKey),
        'api_key_prefix' => substr($plainApiKey, 0, 12),
        'status' => 'active',
        'allowed_services' => $allowedServicesText,
        'created_at' => current_time('mysql'),
        'updated_at' => current_time('mysql'),
      ],
      ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
    );

    if (!$inserted) {
      return new WP_Error('acme_api_consumer_create_failed', 'Não foi possível criar a chave.');
    }

    return [
      'consumer_id' => (int) $wpdb->insert_id,
      'api_key' => $plainApiKey,
      'wp_user_id' => $wpUserId,
      'consumer_name' => $consumerName,
      'allowed_services' => $allowedServicesText,
    ];
  }
}

if (!function_exists('acme_api_consumer_regenerate_key')) {
  function acme_api_consumer_regenerate_key(int $consumerId)
  {
    global $wpdb;

    acme_api_consumers_activate();

    $consumerRow = $wpdb->get_row(
      $wpdb->prepare('SELECT * FROM ' . acme_api_consumers_table() . ' WHERE id = %d LIMIT 1', $consumerId),
      ARRAY_A
    );

    if (!$consumerRow) {
      return new WP_Error('acme_api_consumer_not_found', 'Consumidor não encontrado.');
    }

    $plainApiKey = acme_api_consumer_generate_plain_key();

    $updated = $wpdb->update(
      acme_api_consumers_table(),
      [
        'api_key_hash' => acme_api_consumer_hash_key($plainApiKey),
        'api_key_prefix' => substr($plainApiKey, 0, 12),
        'status' => 'active',
        'updated_at' => current_time('mysql'),
      ],
      ['id' => $consumerId],
      ['%s', '%s', '%s', '%s'],
      ['%d']
    );

    if ($updated === false) {
      return new WP_Error('acme_api_consumer_regenerate_failed', 'Não foi possível regenerar a chave.');
    }

    return [
      'consumer_id' => (int) $consumerId,
      'api_key' => $plainApiKey,
      'wp_user_id' => (int) $consumerRow['wp_user_id'],
      'consumer_name' => (string) $consumerRow['consumer_name'],
      'allowed_services' => (string) $consumerRow['allowed_services'],
    ];
  }
}

if (!function_exists('acme_api_consumer_revoke')) {
  function acme_api_consumer_revoke(int $consumerId): bool
  {
    global $wpdb;

    acme_api_consumers_activate();

    $updated = $wpdb->update(
      acme_api_consumers_table(),
      [
        'status' => 'revoked',
        'updated_at' => current_time('mysql'),
      ],
      ['id' => $consumerId],
      ['%s', '%s'],
      ['%d']
    );

    return $updated !== false;
  }
}

if (!function_exists('acme_api_consumer_get_all')) {
  function acme_api_consumer_get_all(int $limit = 200): array
  {
    global $wpdb;

    acme_api_consumers_activate();

    $limit = max(1, min(500, $limit));
    $tableName = acme_api_consumers_table();

    $sql = $wpdb->prepare("SELECT * FROM {$tableName} ORDER BY id DESC LIMIT %d", $limit);
    $rows = $wpdb->get_results($sql, ARRAY_A);

    return is_array($rows) ? $rows : [];
  }
}
